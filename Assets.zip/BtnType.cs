using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class BTNType : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
 public BtnType currentType;
 public Transform buttonScale;
 Vector3 defaultScale;
public CanvasGroup mainGroup;
public CanvasGroup optionGroup;

 private void Start()
 {
    defaultScale = buttonScale.localScale;
 }
 
bool isSound;
 public void OnBtnClick()
 {
    switch(currentType)
    {
        case BtnType.New:
            Debug.Log("새로운 게임 시작");
            break;
        case BtnType.Continue:
            Debug.Log("이어하기");
            break;
        case BtnType.Option:
            CanvasGroupOn(optionGroup);
            CanvasGroupoff(mainGroup);
            Debug.Log("설정");
            break;
        case BtnType.Sound:
            if(isSound)
            {
                isSound = !isSound;
                Debug.Log("사운드 off");
            }
            else
            {
                Debug.Log("사운드 on");
            }
            break;
        case BtnType.Back:
            CanvasGroupOn(mainGroup);
            CanvasGroupoff(optionGroup);
            Debug.Log("뒤로 가기");
            break;
        case BtnType.Quit:
            Application.Quit();
            Debug.Log("게임 종료");
            break;
    }
 }

 public void CanvasGroupOn(CanvasGroup cg)
 {
    cg.alpha = 1;
    cg.interactable = true;  
    cg.blocksRaycasts = true;

 }

 public void CanvasGroupoff(CanvasGroup cg)
 {
    cg.alpha = 0;
    cg.interactable = false;  
    cg.blocksRaycasts = false;
    
 }
    public void OnPointerEnter(PointerEventData eventData)
    {
        buttonScale.localScale = defaultScale * 1.2f;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        buttonScale.localScale = defaultScale;
    }
}

