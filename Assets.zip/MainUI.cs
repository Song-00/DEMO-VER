using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum BtnType
{
    New,
    Continue,
    Option,
    Sound,
    Back,
    Quit,
}

public class MainUI : MonoBehaviour
{
}
